<?php

return array(
  'customizer-theme-options-button'      => __( 'Customize X in Theme Options', '__x__' ),
  'customizer-theme-options-description' => __( 'Theme Options is the new and preferred place to manage global configuration for X. Take advantage of features like the font manager and quick access to custom CSS and JS code editors. No X related options have been taken away, only moved to a new location. After X version 6.1 (our next major release) the Customizer will only show default WordPress settings.', '__x__' )
);
