<?php

return array(
  'footer-powered-by' => '<p>POWERED BY THE <a href="//theme.co/x/" title="X &ndash; The Ultimate WordPress Theme" rel="nofollow">X THEME</a></p>'
);
